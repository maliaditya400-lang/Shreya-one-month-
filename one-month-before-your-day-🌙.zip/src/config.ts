/**
 * =======================================================================
 * SURPRISE WEBSITE CONFIGURATION SECTION
 * =======================================================================
 * You can easily customize any text, date, or name in this file.
 * Everything will update automatically across the entire site.
 */

export interface AppConfig {
  /** The birthday target date. Format: YYYY-MM-DD or full ISO string */
  birthdayDate: string;

  /** Recipient and Sender */
  recipientName: string;
  senderName: string;

  /** Section 1: Opening view text */
  opening: {
    greeting: string;
    subGreeting: string;
    reassurance: string;
    ctaButton: string;
  };

  /** Section 2: Countdown metrics & captions */
  countdown: {
    heroDaysLabel: string;
    subtitleLine: string;
    caption: string;
    ctaButton: string;
    footerNote: string;
  };

  /** Section 3: The Pop-up Glassmorphic Note */
  card: {
    personalNote: string;
    teaserLine: string;
    subtleLine: string;
    closingLine: string;
    signature: string;
    dateLabel: string;
    closeButton: string;
  };

  /** Section 4: Final fading screen */
  finalScreen: {
    daysRemaining: string;
    dateBadge: string;
    headline: string;
    tagline: string;
    easterEgg: string;
    closeAction: string;
  };
}

/**
 * Helper to dynamically compute next October 19.
 * If today is before or on Oct 19 of current year, target this year;
 * otherwise target next year. Defaults smoothly.
 */
const getTargetBirthday = (): string => {
  const now = new Date();
  const year = now.getMonth() > 9 || (now.getMonth() === 9 && now.getDate() > 19)
    ? now.getFullYear() + 1
    : now.getFullYear();
  return `${year}-10-19T00:00:00`;
};

export const SITE_CONFIG: AppConfig = {
  // -------------------------------------------------------------------
  // 📅 BIRTHDAY DATE CONFIGURATION
  // Change the date here anytime if needed! (Month is 10 for October, Day 19)
  // -------------------------------------------------------------------
  birthdayDate: getTargetBirthday(),

  recipientName: "Shreya",
  senderName: "Aditya",

  // -------------------------------------------------------------------
  // 🌙 OPENING SCREEN
  // -------------------------------------------------------------------
  opening: {
    greeting: "Hey Shreya…",
    subGreeting: "Your birthday is still a month away...",
    reassurance: "But today felt like a good day to remind you that your day is coming. 🌙",
    ctaButton: "Just a little something ✨",
  },

  // -------------------------------------------------------------------
  // ⏳ COUNTDOWN SCREEN
  // -------------------------------------------------------------------
  countdown: {
    heroDaysLabel: "30 DAYS",
    subtitleLine: "until 19 October",
    caption: "Still a little while to go...",
    ctaButton: "Open today's little thing ✨",
    footerNote: "A SMALL NOTE FROM ADITYA",
  },

  // -------------------------------------------------------------------
  // 💌 GLASSMORPHISM CARD MESSAGE (Natural, warm, personal English note)
  // -------------------------------------------------------------------
  card: {
    personalNote: "Might feel random… but since your birthday is still a month away, I just felt like doing a little something today. 😂🌙",
    teaserLine: "Nothing big today…\nThat comes on 19.10. 👀",
    subtleLine: "Until then… keep smiling. 🤎",
    closingLine: "See you on 19.10. 🌙",
    signature: "— Aditya",
    dateLabel: "19.10",
    closeButton: "Close ✨",
  },

  // -------------------------------------------------------------------
  // 🌌 FINAL SCREEN
  // -------------------------------------------------------------------
  finalScreen: {
    daysRemaining: "30 days.",
    dateBadge: "19.10 🌙",
    headline: "Your day is coming.",
    tagline: "Until then… keep smiling. 🤎",
    easterEgg: "Okay that's enough… close this before it gets too emotional 😂",
    closeAction: "Close ✨",
  },
};

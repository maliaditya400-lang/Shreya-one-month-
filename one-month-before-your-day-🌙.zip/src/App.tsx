import React, { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import { NightSkyCanvas } from './components/NightSkyCanvas';
import { OpeningView } from './components/OpeningView';
import { CountdownView } from './components/CountdownView';
import { GlassmorphicCardModal } from './components/GlassmorphicCardModal';
import { FinalScreenView } from './components/FinalScreenView';

type ScreenStage = 'opening' | 'countdown' | 'final';

export default function App() {
  const [stage, setStage] = useState<ScreenStage>('opening');
  const [isCardOpen, setIsCardOpen] = useState<boolean>(false);

  // Handlers for smooth screen progression
  const handleStartCountdown = () => {
    setStage('countdown');
  };

  const handleOpenCard = () => {
    setIsCardOpen(true);
  };

  const handleCloseCard = () => {
    setIsCardOpen(false);
    // As per prompt: "After the card is closed, slowly fade into the night sky. Show: 30 days... 19.10... Your day is coming... Until then... keep smiling."
    if (stage === 'countdown') {
      setStage('final');
    }
  };

  const handleReset = () => {
    setIsCardOpen(false);
    setStage('opening');
  };

  return (
    <main className="relative min-h-screen w-full bg-[#05070d] text-[#f4efe6] overflow-x-hidden flex flex-col items-center justify-center">
      {/* Background Night Sky with realistic twinkling stars, soft moon, and particles */}
      <NightSkyCanvas />

      {/* Subtle vignette border */}
      <div className="fixed inset-0 pointer-events-none ambient-vignette z-[1]" aria-hidden="true" />

      {/* Screen Views with smooth transitions */}
      <div className="relative z-10 w-full min-h-screen flex items-center justify-center">
        <AnimatePresence mode="wait">
          {stage === 'opening' && (
            <OpeningView key="opening" onContinue={handleStartCountdown} />
          )}

          {stage === 'countdown' && (
            <CountdownView key="countdown" onOpenCard={handleOpenCard} />
          )}

          {stage === 'final' && (
            <FinalScreenView
              key="final"
              onReopenCard={handleOpenCard}
              onReset={handleReset}
            />
          )}
        </AnimatePresence>
      </div>

      {/* Glassmorphism Note Card Modal */}
      <GlassmorphicCardModal
        isOpen={isCardOpen}
        onClose={handleCloseCard}
      />
    </main>
  );
}

import React, { useEffect, useRef } from 'react';

interface Star {
  x: number;
  y: number;
  radius: number;
  baseAlpha: number;
  twinkleSpeed: number;
  phase: number;
  color: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  maxLife: number;
  life: number;
}

interface ShootingStar {
  x: number;
  y: number;
  length: number;
  speed: number;
  angle: number;
  alpha: number;
  active: boolean;
}

export const NightSkyCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initStars();
    };

    window.addEventListener('resize', handleResize);

    // Warm ivory and soft starlight palette
    const starColors = [
      'rgba(244, 239, 230, ', // Warm ivory
      'rgba(230, 238, 255, ', // Cool starlight
      'rgba(255, 245, 220, ', // Soft champagne
      'rgba(215, 225, 245, ', // Night blue tint
    ];

    let stars: Star[] = [];
    let particles: Particle[] = [];
    let shootingStar: ShootingStar | null = null;
    let nextShootingStarTime = Date.now() + 4000;

    const initStars = () => {
      stars = [];
      // Star density based on screen size
      const count = Math.min(180, Math.floor((width * height) / 7500));
      for (let i = 0; i < count; i++) {
        const colorBase = starColors[Math.floor(Math.random() * starColors.length)];
        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius: Math.random() * 1.35 + 0.35,
          baseAlpha: Math.random() * 0.55 + 0.25,
          twinkleSpeed: Math.random() * 0.02 + 0.008,
          phase: Math.random() * Math.PI * 2,
          color: colorBase,
        });
      }
    };

    const spawnParticle = () => {
      if (particles.length < 35) {
        particles.push({
          x: Math.random() * width,
          y: height + 10,
          vx: (Math.random() - 0.5) * 0.2,
          vy: -(Math.random() * 0.35 + 0.15),
          radius: Math.random() * 1.1 + 0.4,
          alpha: Math.random() * 0.4 + 0.1,
          maxLife: Math.random() * 400 + 300,
          life: 0,
        });
      }
    };

    const triggerShootingStar = () => {
      const angle = (Math.PI / 6) + (Math.random() * 0.2 - 0.1); // ~30 deg downward
      shootingStar = {
        x: Math.random() * (width * 0.7),
        y: Math.random() * (height * 0.35),
        length: Math.random() * 80 + 60,
        speed: Math.random() * 7 + 9,
        angle: angle,
        alpha: 0.85,
        active: true,
      };
      nextShootingStarTime = Date.now() + Math.random() * 12000 + 9000;
    };

    initStars();

    let lastTime = performance.now();

    const render = (time: number) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      // Clear with dark night gradient
      ctx.clearRect(0, 0, width, height);

      // Deep sky background
      const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
      skyGrad.addColorStop(0, '#04060b');
      skyGrad.addColorStop(0.5, '#070a13');
      skyGrad.addColorStop(1, '#080d19');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, width, height);

      // Soft moonlight glow in the upper corner (cinematic lighting)
      const moonX = width > 768 ? width * 0.78 : width * 0.82;
      const moonY = height * 0.16;
      const moonGlow = ctx.createRadialGradient(moonX, moonY, 10, moonX, moonY, Math.min(width, height) * 0.55);
      moonGlow.addColorStop(0, 'rgba(245, 238, 222, 0.09)');
      moonGlow.addColorStop(0.3, 'rgba(230, 238, 255, 0.035)');
      moonGlow.addColorStop(0.7, 'rgba(100, 140, 200, 0.015)');
      moonGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = moonGlow;
      ctx.fillRect(0, 0, width, height);

      // Delicate Crescent Moon silhouette
      const moonR = width > 768 ? 26 : 20;
      ctx.save();
      ctx.shadowColor = 'rgba(255, 245, 225, 0.45)';
      ctx.shadowBlur = 18;
      ctx.fillStyle = 'rgba(244, 239, 230, 0.88)';
      ctx.beginPath();
      ctx.arc(moonX, moonY, moonR, 0, Math.PI * 2);
      ctx.fill();

      // Subtly carve inner shadow to form crescent
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(moonX - moonR * 0.55, moonY - moonR * 0.35, moonR * 0.92, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Render twinkling stars
      for (let i = 0; i < stars.length; i++) {
        const star = stars[i];
        star.phase += star.twinkleSpeed;
        const currentAlpha = star.baseAlpha + Math.sin(star.phase) * (star.baseAlpha * 0.55);
        ctx.fillStyle = `${star.color}${Math.max(0.05, Math.min(0.95, currentAlpha))})`;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // Floating gentle particles
      if (Math.random() < 0.1) {
        spawnParticle();
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life += 1;
        p.x += p.vx;
        p.y += p.vy;

        const progress = p.life / p.maxLife;
        const fade = Math.sin(progress * Math.PI) * p.alpha;

        ctx.fillStyle = `rgba(245, 238, 225, ${Math.max(0, fade)})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();

        if (p.life >= p.maxLife || p.y < -10) {
          particles.splice(i, 1);
        }
      }

      // Check shooting star
      if (!shootingStar && Date.now() > nextShootingStarTime) {
        triggerShootingStar();
      }

      if (shootingStar && shootingStar.active) {
        const dx = Math.cos(shootingStar.angle) * shootingStar.speed;
        const dy = Math.sin(shootingStar.angle) * shootingStar.speed;
        shootingStar.x += dx;
        shootingStar.y += dy;
        shootingStar.alpha -= 0.015;

        if (shootingStar.alpha <= 0) {
          shootingStar.active = false;
          shootingStar = null;
        } else {
          const tailX = shootingStar.x - Math.cos(shootingStar.angle) * shootingStar.length;
          const tailY = shootingStar.y - Math.sin(shootingStar.angle) * shootingStar.length;
          const grad = ctx.createLinearGradient(tailX, tailY, shootingStar.x, shootingStar.y);
          grad.addColorStop(0, 'rgba(255, 245, 230, 0)');
          grad.addColorStop(0.8, `rgba(255, 245, 230, ${shootingStar.alpha * 0.4})`);
          grad.addColorStop(1, `rgba(255, 255, 255, ${shootingStar.alpha})`);

          ctx.strokeStyle = grad;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(tailX, tailY);
          ctx.lineTo(shootingStar.x, shootingStar.y);
          ctx.stroke();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none z-0"
      aria-hidden="true"
    />
  );
};

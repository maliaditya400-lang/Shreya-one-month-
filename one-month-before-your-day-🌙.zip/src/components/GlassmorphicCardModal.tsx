import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Moon, Sparkles } from 'lucide-react';
import { SITE_CONFIG } from '../config';

interface GlassmorphicCardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlassmorphicCardModal: React.FC<GlassmorphicCardModalProps> = ({
  isOpen,
  onClose,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          {/* Backdrop blur with soft vignette */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/65 backdrop-blur-md"
            aria-hidden="true"
          />

          {/* Glassmorphism Card */}
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Note for Shreya"
            initial={{ opacity: 0, scale: 0.94, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-lg rounded-3xl glass-panel p-7 sm:p-10 text-left z-10 border border-white/10 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8),0_0_30px_rgba(244,239,230,0.05)] overflow-hidden"
          >
            {/* Subtle moon glow spot inside card */}
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 rounded-full bg-amber-200/5 blur-3xl pointer-events-none" />

            {/* Header row with celestial icon and close button */}
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/[0.06]">
              <div className="flex items-center gap-2 text-xs text-[#a49e92] tracking-widest uppercase">
                <Moon className="w-3.5 h-3.5 text-[#deb887]" />
                <span>Just a little thing</span>
              </div>
              <button
                id="close-card-top-btn"
                onClick={onClose}
                aria-label="Close note"
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#999285] hover:text-[#f4efe6] hover:bg-white/[0.06] transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Main Message Body */}
            <div className="space-y-6 text-[#ded8cd] font-sans-clean leading-relaxed font-light text-base sm:text-lg">
              {/* Natural, personal note */}
              <p className="text-lg sm:text-xl text-[#f4efe6] font-normal leading-relaxed">
                {SITE_CONFIG.card.personalNote}
              </p>

              {/* Teaser line with subtle divider */}
              <div className="pt-2 pb-1 border-t border-white/[0.05]">
                <p className="text-base sm:text-lg text-[#d8d2c6] whitespace-pre-line leading-relaxed">
                  {SITE_CONFIG.card.teaserLine}
                </p>
              </div>

              {/* Smaller subtle line */}
              <p className="text-sm sm:text-base text-[#b8b0a1] italic tracking-wide">
                {SITE_CONFIG.card.subtleLine}
              </p>

              {/* Countdown reminder */}
              <p className="text-base sm:text-lg text-[#ded8cd] font-serif-elegant font-normal tracking-wide pt-1">
                {SITE_CONFIG.card.closingLine}
              </p>

              {/* Personal signature */}
              <div className="pt-3 flex items-center justify-between border-t border-white/[0.05]">
                <span className="text-base sm:text-lg font-serif-elegant italic text-[#f4efe6] font-medium tracking-wide">
                  {SITE_CONFIG.card.signature}
                </span>
                <span className="text-xs text-[#827c70] font-mono tracking-wider">
                  {SITE_CONFIG.card.dateLabel}
                </span>
              </div>
            </div>

            {/* Action button at bottom */}
            <div className="mt-8 pt-5 border-t border-white/[0.06] flex justify-end">
              <button
                id="close-card-action-btn"
                onClick={onClose}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-xs font-medium tracking-wider uppercase text-[#0a0d14] bg-[#f4efe6] hover:bg-[#ffffff] transition-all duration-200 shadow-md active:scale-95 cursor-pointer"
              >
                <span>{SITE_CONFIG.card.closeButton}</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

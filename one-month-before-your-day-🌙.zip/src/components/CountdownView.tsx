import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Moon, Sparkles, Clock } from 'lucide-react';
import { SITE_CONFIG } from '../config';

interface CountdownViewProps {
  onOpenCard: () => void;
}

interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  totalHours: number;
  totalMinutes: number;
}

export const CountdownView: React.FC<CountdownViewProps> = ({ onOpenCard }) => {
  const [timeLeft, setTimeLeft] = useState<TimeRemaining>(() => {
    return calculateTimeRemaining(SITE_CONFIG.birthdayDate);
  });

  function calculateTimeRemaining(targetDateStr: string): TimeRemaining {
    const target = new Date(targetDateStr).getTime();
    const now = Date.now();
    const difference = Math.max(0, target - now);

    const totalSeconds = Math.floor(difference / 1000);
    const totalMinutes = Math.floor(totalSeconds / 60);
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);

    const hours = totalHours % 24;
    const minutes = totalMinutes % 60;
    const seconds = totalSeconds % 60;

    return {
      days,
      hours,
      minutes,
      seconds,
      totalHours,
      totalMinutes,
    };
  }

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeRemaining(SITE_CONFIG.birthdayDate));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <motion.section
      key="countdown-view"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
      className="relative z-10 flex flex-col items-center justify-center min-h-screen px-5 py-12 text-center max-w-xl mx-auto"
    >
      {/* Delicate header pill */}
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.8 }}
        className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-pill text-xs tracking-widest text-[#cfc7b9] uppercase mb-8"
      >
        <Moon className="w-3.5 h-3.5 text-[#f4efe6]" />
        <span>One Month Before Your Day</span>
      </motion.div>

      {/* Main Milestone Countdown Display */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4, duration: 1 }}
        className="w-full flex flex-col items-center mb-8"
      >
        {/* "30 DAYS" Hero Display */}
        <div className="relative mb-2">
          <div className="font-serif-elegant text-6xl sm:text-7xl md:text-8xl font-light text-[#f4efe6] tracking-tight leading-none drop-shadow-[0_0_24px_rgba(244,239,230,0.15)]">
            {SITE_CONFIG.countdown.heroDaysLabel}
          </div>
        </div>

        {/* Subtle small line directly below "30 DAYS" */}
        <p className="text-sm sm:text-base text-[#b0a99c] font-light tracking-wide mb-7 font-sans-clean">
          {SITE_CONFIG.countdown.subtitleLine}
        </p>

        {/* Live precision countdown clock that ticks every second */}
        <div className="inline-flex items-center justify-center gap-2 sm:gap-3 px-5 py-3 rounded-2xl glass-panel text-[#e6ded2] shadow-xl">
          <div className="flex items-center gap-1.5 text-xs text-[#9d968a] mr-1 uppercase tracking-wider font-sans-clean">
            <Clock className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Live:</span>
          </div>

          <div className="flex items-center gap-1 text-center font-mono">
            <div className="flex flex-col items-center min-w-[2.6rem]">
              <span className="text-base sm:text-lg font-medium text-[#f4efe6]">{String(timeLeft.days).padStart(2, '0')}</span>
              <span className="text-[9px] text-[#8e877a] uppercase tracking-wider">Days</span>
            </div>
            <span className="text-[#8e877a] text-sm pb-3">:</span>

            <div className="flex flex-col items-center min-w-[2.6rem]">
              <span className="text-base sm:text-lg font-medium text-[#f4efe6]">{String(timeLeft.hours).padStart(2, '0')}</span>
              <span className="text-[9px] text-[#8e877a] uppercase tracking-wider">Hrs</span>
            </div>
            <span className="text-[#8e877a] text-sm pb-3">:</span>

            <div className="flex flex-col items-center min-w-[2.6rem]">
              <span className="text-base sm:text-lg font-medium text-[#f4efe6]">{String(timeLeft.minutes).padStart(2, '0')}</span>
              <span className="text-[9px] text-[#8e877a] uppercase tracking-wider">Min</span>
            </div>
            <span className="text-[#8e877a] text-sm pb-3">:</span>

            <div className="flex flex-col items-center min-w-[2.6rem]">
              <span className="text-base sm:text-lg font-medium text-[#deb887]">{String(timeLeft.seconds).padStart(2, '0')}</span>
              <span className="text-[9px] text-[#8e877a] uppercase tracking-wider">Sec</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Caption text */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 1 }}
        className="font-serif-elegant italic text-lg sm:text-xl text-[#c7bfb1] mb-12 tracking-wide"
      >
        "{SITE_CONFIG.countdown.caption}"
      </motion.p>

      {/* Main Interaction: Glowing moon/star button */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.1, duration: 0.9 }}
        className="flex flex-col items-center"
      >
        <button
          id="open-note-btn"
          onClick={onOpenCard}
          className="group relative inline-flex items-center justify-center gap-3 px-7 py-4 rounded-full text-sm font-medium tracking-wide text-[#f4efe6] bg-[#111622]/80 hover:bg-[#161d2d] border border-white/15 hover:border-white/30 transition-all duration-300 shadow-[0_0_28px_rgba(244,239,230,0.08)] hover:shadow-[0_0_36px_rgba(244,239,230,0.18)] active:scale-[0.98] cursor-pointer"
        >
          {/* Subtle glowing halo */}
          <span className="absolute -inset-0.5 rounded-full bg-gradient-to-r from-amber-100/10 via-amber-200/20 to-amber-100/10 opacity-75 blur-md group-hover:opacity-100 transition duration-500 pointer-events-none" />

          <Moon className="w-4 h-4 text-[#deb887] relative z-10 transition-transform duration-300 group-hover:-rotate-12" />
          <span className="relative z-10 font-sans-clean font-medium">
            {SITE_CONFIG.countdown.ctaButton}
          </span>
          <Sparkles className="w-3.5 h-3.5 text-[#deb887] relative z-10" />
        </button>

        <span className="mt-4 text-[11px] text-[#787267] tracking-widest uppercase font-light">
          {SITE_CONFIG.countdown.footerNote}
        </span>
      </motion.div>
    </motion.section>
  );
};

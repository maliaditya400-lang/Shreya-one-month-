import React from 'react';
import { motion } from 'motion/react';
import { Moon, Sparkles, RotateCcw, BookOpen } from 'lucide-react';
import { SITE_CONFIG } from '../config';

interface FinalScreenViewProps {
  onReopenCard: () => void;
  onReset: () => void;
}

export const FinalScreenView: React.FC<FinalScreenViewProps> = ({
  onReopenCard,
  onReset,
}) => {
  return (
    <motion.section
      key="final-screen"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1.6, ease: [0.16, 1, 0.3, 1] }}
      className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12 text-center max-w-lg mx-auto"
    >
      {/* 30 days headline */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 1.1 }}
        className="mb-4"
      >
        <span className="font-serif-elegant text-5xl sm:text-6xl md:text-7xl font-light text-[#f4efe6] tracking-tight drop-shadow-[0_0_20px_rgba(244,239,230,0.18)]">
          {SITE_CONFIG.finalScreen.daysRemaining}
        </span>
      </motion.div>

      {/* Date badge: 19.10 🌙 */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.9, duration: 1 }}
        className="inline-flex items-center gap-2 px-5 py-2 rounded-full glass-panel text-sm font-mono tracking-widest text-[#ded8cd] mb-7"
      >
        <span>{SITE_CONFIG.finalScreen.dateBadge}</span>
      </motion.div>

      {/* Your day is coming. */}
      <motion.h2
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.4, duration: 1 }}
        className="font-serif-elegant text-2xl sm:text-3xl text-[#f4efe6] font-normal tracking-wide mb-3"
      >
        {SITE_CONFIG.finalScreen.headline}
      </motion.h2>

      {/* Until then… keep smiling. 🤎 */}
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.9, duration: 1 }}
        className="font-sans-clean text-sm sm:text-base text-[#b5ad9e] font-light tracking-wide mb-10"
      >
        {SITE_CONFIG.finalScreen.tagline}
      </motion.p>

      {/* Action controls */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 2.3, duration: 0.9 }}
        className="flex flex-col sm:flex-row items-center gap-3"
      >
        {/* Subtle Close / Meditative star gaze button */}
        <button
          id="final-close-btn"
          onClick={onReopenCard}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full glass-pill text-xs font-medium tracking-wider uppercase text-[#e6ded2] hover:text-[#ffffff] transition-all duration-300 cursor-pointer active:scale-95"
        >
          <BookOpen className="w-3.5 h-3.5 text-[#deb887]" />
          <span>Read note again</span>
        </button>

        <button
          id="final-reset-btn"
          onClick={onReset}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs text-[#807a6f] hover:text-[#ded8cd] transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3 h-3" />
          <span>From beginning</span>
        </button>
      </motion.div>

      {/* 6. Personal Easter Egg at the very bottom */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.75 }}
        transition={{ delay: 3.0, duration: 1.2 }}
        className="mt-14 text-xs sm:text-[13px] text-[#868074] font-sans-clean font-light tracking-wide italic"
      >
        {SITE_CONFIG.finalScreen.easterEgg}
      </motion.p>
    </motion.section>
  );
};

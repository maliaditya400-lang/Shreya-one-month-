import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Moon } from 'lucide-react';
import { SITE_CONFIG } from '../config';

interface OpeningViewProps {
  onContinue: () => void;
}

export const OpeningView: React.FC<OpeningViewProps> = ({ onContinue }) => {
  return (
    <motion.section
      key="opening-view"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
      className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-12 text-center max-w-2xl mx-auto"
    >
      {/* Soft celestial icon */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 1 }}
        className="mb-8 flex items-center justify-center"
      >
        <div className="w-12 h-12 rounded-full flex items-center justify-center glass-pill text-[#e7ddcf]">
          <Moon className="w-5 h-5 text-[#f4efe6] drop-shadow-[0_0_8px_rgba(244,239,230,0.5)]" />
        </div>
      </motion.div>

      {/* Main Greeting */}
      <motion.h1
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 1 }}
        className="font-serif-elegant text-4xl sm:text-5xl md:text-6xl text-[#f4efe6] font-light tracking-wide mb-6 leading-tight"
      >
        {SITE_CONFIG.opening.greeting}
      </motion.h1>

      {/* Small calm text */}
      <motion.p
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="text-sm sm:text-base text-[#b8b2a7] font-sans-clean font-light tracking-wider uppercase mb-5"
      >
        {SITE_CONFIG.opening.subGreeting}
      </motion.p>

      {/* Reassurance text */}
      <motion.p
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.7, duration: 1.1 }}
        className="text-lg sm:text-xl text-[#ded8cd] font-light max-w-lg leading-relaxed mb-12 font-sans-clean"
      >
        {SITE_CONFIG.opening.reassurance}
      </motion.p>

      {/* Interactive transition button */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 2.2, duration: 1 }}
      >
        <button
          id="opening-cta-btn"
          onClick={onContinue}
          className="group relative inline-flex items-center gap-2.5 px-8 py-4 rounded-full text-sm font-medium tracking-wide text-[#070a12] bg-[#f4efe6] hover:bg-[#ffffff] transition-all duration-300 shadow-[0_0_24px_rgba(244,239,230,0.22)] hover:shadow-[0_0_32px_rgba(244,239,230,0.38)] active:scale-[0.98] cursor-pointer"
        >
          <span>{SITE_CONFIG.opening.ctaButton}</span>
        </button>
      </motion.div>

      {/* Subtle bottom note */}
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.45 }}
        transition={{ delay: 2.8, duration: 1 }}
        className="mt-14 text-xs text-[#8c867b] tracking-widest uppercase font-light"
      >
        19 October Countdown
      </motion.span>
    </motion.section>
  );
};
